# Приклад голосового керування
import speech_recognition as sr
