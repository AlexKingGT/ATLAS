ATLAS 2.1 — README
------------------
1. Встанови ollama: https://ollama.ai
2. Запусти run.sh (Linux/macOS) або run.bat (Windows), щоб створити моделі.
3. Використовуй ATLAS через команду: ollama run atlas-universal
4. Додаткові можливості реалізовані у Python-скриптах:
   - read_files.py — читання файлів (docx, pdf, xlsx, rar, pkt)
   - voice_control.py — голосове керування
   - web_search.py — пошук у мережі Інтернет
5. Мови: українська (основна), англійська (допоміжна). Російська мова заборонена.
