# Приклад інтеграції з інтернетом
import requests, bs4
