# Приклад читання файлів (docx, pdf, xlsx, rar, pkt)
import docx, PyPDF2, openpyxl, rarfile
