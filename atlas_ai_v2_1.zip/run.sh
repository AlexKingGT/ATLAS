ollama create atlas-universal -f Modelfile-universal
ollama create atlas-pentest -f Modelfile-pentest
ollama create atlas-radio -f Modelfile-radio
